# -*- coding: utf-8 -*-

from djadmin.admin import DeleteModelAdmin, ReadonlyModelAdmin
